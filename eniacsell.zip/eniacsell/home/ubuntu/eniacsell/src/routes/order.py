from flask import Blueprint, jsonify, request, session
from src.models.user import Order, OrderItem, Product, User, db

order_bp = Blueprint('order', __name__)

def require_login():
    if 'user_id' not in session:
        return jsonify({'error': 'Login required'}), 401
    return None

def require_admin():
    if 'user_id' not in session or not session.get('is_admin'):
        return jsonify({'error': 'Admin access required'}), 403
    return None

@order_bp.route('/orders', methods=['GET'])
def get_orders():
    login_check = require_login()
    if login_check:
        return login_check
    
    user_id = session['user_id']
    is_admin = session.get('is_admin', False)
    
    if is_admin:
        # Admin pode ver todos os pedidos
        orders = Order.query.all()
    else:
        # Usuário comum só vê seus próprios pedidos
        orders = Order.query.filter_by(user_id=user_id).all()
    
    return jsonify([order.to_dict() for order in orders])

@order_bp.route('/orders/<int:order_id>', methods=['GET'])
def get_order(order_id):
    login_check = require_login()
    if login_check:
        return login_check
    
    order = Order.query.get_or_404(order_id)
    user_id = session['user_id']
    is_admin = session.get('is_admin', False)
    
    # Verificar se o usuário pode ver este pedido
    if not is_admin and order.user_id != user_id:
        return jsonify({'error': 'Access denied'}), 403
    
    return jsonify(order.to_dict())

@order_bp.route('/orders', methods=['POST'])
def create_order():
    login_check = require_login()
    if login_check:
        return login_check
    
    data = request.json
    user_id = session['user_id']
    
    # Validar dados do pedido
    if not data.get('items') or len(data['items']) == 0:
        return jsonify({'error': 'Order must have at least one item'}), 400
    
    # Criar o pedido
    order = Order(
        user_id=user_id,
        total_amount=0,  # Será calculado
        shipping_address=data['shipping_address'],
        shipping_city=data['shipping_city'],
        shipping_state=data['shipping_state'],
        shipping_zip=data['shipping_zip']
    )
    
    db.session.add(order)
    db.session.flush()  # Para obter o ID do pedido
    
    total_amount = 0
    
    # Adicionar itens do pedido
    for item_data in data['items']:
        product = Product.query.get(item_data['product_id'])
        if not product:
            return jsonify({'error': f'Product {item_data["product_id"]} not found'}), 400
        
        if product.stock_quantity < item_data['quantity']:
            return jsonify({'error': f'Insufficient stock for product {product.name}'}), 400
        
        # Criar item do pedido
        order_item = OrderItem(
            order_id=order.id,
            product_id=product.id,
            quantity=item_data['quantity'],
            price=product.price
        )
        
        # Atualizar estoque
        product.stock_quantity -= item_data['quantity']
        
        total_amount += order_item.quantity * order_item.price
        db.session.add(order_item)
    
    order.total_amount = total_amount
    db.session.commit()
    
    return jsonify(order.to_dict()), 201

@order_bp.route('/orders/<int:order_id>/status', methods=['PUT'])
def update_order_status(order_id):
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    order = Order.query.get_or_404(order_id)
    data = request.json
    
    valid_statuses = ['pending', 'confirmed', 'shipped', 'delivered', 'cancelled']
    new_status = data.get('status')
    
    if new_status not in valid_statuses:
        return jsonify({'error': 'Invalid status'}), 400
    
    order.status = new_status
    db.session.commit()
    
    return jsonify(order.to_dict())

@order_bp.route('/cart/add', methods=['POST'])
def add_to_cart():
    login_check = require_login()
    if login_check:
        return login_check
    
    data = request.json
    product_id = data.get('product_id')
    quantity = data.get('quantity', 1)
    
    product = Product.query.get_or_404(product_id)
    
    if product.stock_quantity < quantity:
        return jsonify({'error': 'Insufficient stock'}), 400
    
    # Usar sessão para carrinho temporário
    if 'cart' not in session:
        session['cart'] = {}
    
    cart = session['cart']
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        cart[product_id_str] += quantity
    else:
        cart[product_id_str] = quantity
    
    session['cart'] = cart
    
    return jsonify({'message': 'Product added to cart', 'cart': cart})

@order_bp.route('/cart', methods=['GET'])
def get_cart():
    login_check = require_login()
    if login_check:
        return login_check
    
    cart = session.get('cart', {})
    cart_items = []
    total = 0
    
    for product_id_str, quantity in cart.items():
        product = Product.query.get(int(product_id_str))
        if product:
            subtotal = product.price * quantity
            cart_items.append({
                'product': product.to_dict(),
                'quantity': quantity,
                'subtotal': subtotal
            })
            total += subtotal
    
    return jsonify({
        'items': cart_items,
        'total': total
    })

@order_bp.route('/cart/remove/<int:product_id>', methods=['DELETE'])
def remove_from_cart(product_id):
    login_check = require_login()
    if login_check:
        return login_check
    
    cart = session.get('cart', {})
    product_id_str = str(product_id)
    
    if product_id_str in cart:
        del cart[product_id_str]
        session['cart'] = cart
    
    return jsonify({'message': 'Product removed from cart', 'cart': cart})

@order_bp.route('/cart/clear', methods=['DELETE'])
def clear_cart():
    login_check = require_login()
    if login_check:
        return login_check
    
    session['cart'] = {}
    return jsonify({'message': 'Cart cleared'})

