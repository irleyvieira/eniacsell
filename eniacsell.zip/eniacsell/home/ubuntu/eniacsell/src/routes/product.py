from flask import Blueprint, jsonify, request, session
from src.models.user import Product, db

product_bp = Blueprint('product', __name__)

def require_admin():
    if 'user_id' not in session or not session.get('is_admin'):
        return jsonify({'error': 'Admin access required'}), 403
    return None

@product_bp.route('/products', methods=['GET'])
def get_products():
    # Filtros opcionais
    category = request.args.get('category')
    active_only = request.args.get('active', 'true').lower() == 'true'
    
    query = Product.query
    
    if active_only:
        query = query.filter_by(is_active=True)
    
    if category:
        query = query.filter_by(category=category)
    
    products = query.all()
    return jsonify([product.to_dict() for product in products])

@product_bp.route('/products/<int:product_id>', methods=['GET'])
def get_product(product_id):
    product = Product.query.get_or_404(product_id)
    return jsonify(product.to_dict())

@product_bp.route('/products', methods=['POST'])
def create_product():
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    data = request.json
    product = Product(
        name=data['name'],
        description=data.get('description'),
        price=data['price'],
        stock_quantity=data.get('stock_quantity', 0),
        image_url=data.get('image_url'),
        category=data.get('category'),
        is_active=data.get('is_active', True)
    )
    
    db.session.add(product)
    db.session.commit()
    return jsonify(product.to_dict()), 201

@product_bp.route('/products/<int:product_id>', methods=['PUT'])
def update_product(product_id):
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    product = Product.query.get_or_404(product_id)
    data = request.json
    
    product.name = data.get('name', product.name)
    product.description = data.get('description', product.description)
    product.price = data.get('price', product.price)
    product.stock_quantity = data.get('stock_quantity', product.stock_quantity)
    product.image_url = data.get('image_url', product.image_url)
    product.category = data.get('category', product.category)
    product.is_active = data.get('is_active', product.is_active)
    
    db.session.commit()
    return jsonify(product.to_dict())

@product_bp.route('/products/<int:product_id>', methods=['DELETE'])
def delete_product(product_id):
    admin_check = require_admin()
    if admin_check:
        return admin_check
    
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    return '', 204

@product_bp.route('/categories', methods=['GET'])
def get_categories():
    categories = db.session.query(Product.category).filter(Product.category.isnot(None)).distinct().all()
    return jsonify([cat[0] for cat in categories if cat[0]])

