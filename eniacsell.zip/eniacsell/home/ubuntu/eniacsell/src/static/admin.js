// Global variables
let currentUser = null;
let products = [];
let orders = [];
let users = [];

// API base URL
const API_BASE = '/api';

// Initialize admin panel
document.addEventListener('DOMContentLoaded', function() {
    checkAdminAuth();
    loadDashboardData();
});

// Authentication check
async function checkAdminAuth() {
    try {
        const response = await fetch(`${API_BASE}/current-user`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            currentUser = await response.json();
            if (!currentUser.is_admin) {
                showMessage('Acesso negado. Apenas administradores podem acessar esta página.', 'error');
                setTimeout(() => {
                    window.location.href = '/';
                }, 2000);
                return;
            }
        } else {
            showMessage('Faça login como administrador para acessar esta página.', 'error');
            setTimeout(() => {
                window.location.href = '/';
            }, 2000);
            return;
        }
    } catch (error) {
        console.error('Error checking admin auth:', error);
        showMessage('Erro de conexão', 'error');
        setTimeout(() => {
            window.location.href = '/';
        }, 2000);
    }
}

// Navigation functions
function showSection(sectionId) {
    // Hide all sections
    document.querySelectorAll('.admin-section').forEach(section => {
        section.classList.remove('active');
    });
    
    // Remove active class from all nav buttons
    document.querySelectorAll('.admin-nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected section
    document.getElementById(sectionId).classList.add('active');
    
    // Add active class to clicked button
    event.target.classList.add('active');
    
    // Load data for the section
    switch(sectionId) {
        case 'dashboard':
            loadDashboardData();
            break;
        case 'products':
            loadProducts();
            break;
        case 'orders':
            loadOrders();
            break;
        case 'users':
            loadUsers();
            break;
    }
}

function goToStore() {
    window.location.href = '/';
}

async function logout() {
    try {
        await fetch(`${API_BASE}/logout`, {
            method: 'POST',
            credentials: 'include'
        });
        
        window.location.href = '/';
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Dashboard functions
async function loadDashboardData() {
    try {
        // Load products count
        const productsResponse = await fetch(`${API_BASE}/products`);
        const productsData = await productsResponse.json();
        document.getElementById('totalProducts').textContent = productsData.length;
        
        // Load orders count and revenue
        const ordersResponse = await fetch(`${API_BASE}/orders`, {
            credentials: 'include'
        });
        if (ordersResponse.ok) {
            const ordersData = await ordersResponse.json();
            document.getElementById('totalOrders').textContent = ordersData.length;
            
            const totalRevenue = ordersData.reduce((sum, order) => sum + order.total_amount, 0);
            document.getElementById('totalRevenue').textContent = `R$ ${totalRevenue.toFixed(2).replace('.', ',')}`;
        }
        
        // Load users count
        const usersResponse = await fetch(`${API_BASE}/users`, {
            credentials: 'include'
        });
        if (usersResponse.ok) {
            const usersData = await usersResponse.json();
            document.getElementById('totalUsers').textContent = usersData.length;
        }
        
    } catch (error) {
        console.error('Error loading dashboard data:', error);
    }
}

// Products functions
async function loadProducts() {
    const loading = document.getElementById('productsLoading');
    const tableBody = document.getElementById('productsTableBody');
    
    loading.style.display = 'block';
    
    try {
        const response = await fetch(`${API_BASE}/products?active=false`); // Load all products including inactive
        products = await response.json();
        displayProducts();
    } catch (error) {
        console.error('Error loading products:', error);
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Erro ao carregar produtos</td></tr>';
    } finally {
        loading.style.display = 'none';
    }
}

function displayProducts() {
    const tableBody = document.getElementById('productsTableBody');
    
    if (products.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Nenhum produto encontrado</td></tr>';
        return;
    }
    
    tableBody.innerHTML = products.map(product => `
        <tr>
            <td>
                <div class="product-image-small">
                    ${product.image_url ? 
                        `<img src="${product.image_url}" alt="${product.name}">` : 
                        '<i class="fas fa-image"></i>'
                    }
                </div>
            </td>
            <td>${product.name}</td>
            <td>R$ ${product.price.toFixed(2).replace('.', ',')}</td>
            <td>${product.stock_quantity}</td>
            <td>${product.category || '-'}</td>
            <td>
                <span class="status-badge ${product.is_active ? 'status-active' : 'status-inactive'}">
                    ${product.is_active ? 'Ativo' : 'Inativo'}
                </span>
            </td>
            <td>
                <button class="action-btn" onclick="editProduct(${product.id})" title="Editar">
                    <i class="fas fa-edit"></i>
                </button>
                <button class="action-btn delete" onclick="deleteProduct(${product.id})" title="Excluir">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function showAddProductModal() {
    document.getElementById('productModalTitle').textContent = 'Adicionar Produto';
    document.getElementById('productForm').reset();
    document.getElementById('productId').value = '';
    document.getElementById('productActive').checked = true;
    showModal('productModal');
}

function editProduct(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    document.getElementById('productModalTitle').textContent = 'Editar Produto';
    document.getElementById('productId').value = product.id;
    document.getElementById('productName').value = product.name;
    document.getElementById('productDescription').value = product.description || '';
    document.getElementById('productPrice').value = product.price;
    document.getElementById('productStock').value = product.stock_quantity;
    document.getElementById('productCategory').value = product.category || '';
    document.getElementById('productImageUrl').value = product.image_url || '';
    document.getElementById('productActive').checked = product.is_active;
    
    showModal('productModal');
}

async function handleProductSubmit(event) {
    event.preventDefault();
    
    const productId = document.getElementById('productId').value;
    const productData = {
        name: document.getElementById('productName').value,
        description: document.getElementById('productDescription').value,
        price: parseFloat(document.getElementById('productPrice').value),
        stock_quantity: parseInt(document.getElementById('productStock').value),
        category: document.getElementById('productCategory').value,
        image_url: document.getElementById('productImageUrl').value,
        is_active: document.getElementById('productActive').checked
    };
    
    try {
        let response;
        if (productId) {
            // Update existing product
            response = await fetch(`${API_BASE}/products/${productId}`, {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify(productData)
            });
        } else {
            // Create new product
            response = await fetch(`${API_BASE}/products`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                credentials: 'include',
                body: JSON.stringify(productData)
            });
        }
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage(productId ? 'Produto atualizado com sucesso!' : 'Produto criado com sucesso!', 'success');
            closeModal('productModal');
            loadProducts();
            loadDashboardData(); // Update dashboard stats
        } else {
            showMessage(data.error || 'Erro ao salvar produto', 'error');
        }
    } catch (error) {
        console.error('Error saving product:', error);
        showMessage('Erro de conexão', 'error');
    }
}

async function deleteProduct(productId) {
    if (!confirm('Tem certeza que deseja excluir este produto?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/products/${productId}`, {
            method: 'DELETE',
            credentials: 'include'
        });
        
        if (response.ok) {
            showMessage('Produto excluído com sucesso!', 'success');
            loadProducts();
            loadDashboardData(); // Update dashboard stats
        } else {
            const data = await response.json();
            showMessage(data.error || 'Erro ao excluir produto', 'error');
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        showMessage('Erro de conexão', 'error');
    }
}

// Orders functions
async function loadOrders() {
    const loading = document.getElementById('ordersLoading');
    const tableBody = document.getElementById('ordersTableBody');
    
    loading.style.display = 'block';
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            orders = await response.json();
            displayOrders();
        } else {
            tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Erro ao carregar pedidos</td></tr>';
        }
    } catch (error) {
        console.error('Error loading orders:', error);
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Erro ao carregar pedidos</td></tr>';
    } finally {
        loading.style.display = 'none';
    }
}

function displayOrders() {
    const tableBody = document.getElementById('ordersTableBody');
    
    if (orders.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="6" class="text-center">Nenhum pedido encontrado</td></tr>';
        return;
    }
    
    tableBody.innerHTML = orders.map(order => `
        <tr>
            <td>#${order.id}</td>
            <td>${order.user ? order.user.full_name || order.user.username : 'N/A'}</td>
            <td>R$ ${order.total_amount.toFixed(2).replace('.', ',')}</td>
            <td>
                <select onchange="updateOrderStatus(${order.id}, this.value)">
                    <option value="pending" ${order.status === 'pending' ? 'selected' : ''}>Pendente</option>
                    <option value="confirmed" ${order.status === 'confirmed' ? 'selected' : ''}>Confirmado</option>
                    <option value="shipped" ${order.status === 'shipped' ? 'selected' : ''}>Enviado</option>
                    <option value="delivered" ${order.status === 'delivered' ? 'selected' : ''}>Entregue</option>
                    <option value="cancelled" ${order.status === 'cancelled' ? 'selected' : ''}>Cancelado</option>
                </select>
            </td>
            <td>${new Date(order.created_at).toLocaleDateString('pt-BR')}</td>
            <td>
                <button class="action-btn" onclick="viewOrderDetail(${order.id})" title="Ver Detalhes">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

async function updateOrderStatus(orderId, newStatus) {
    try {
        const response = await fetch(`${API_BASE}/orders/${orderId}/status`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ status: newStatus })
        });
        
        if (response.ok) {
            showMessage('Status do pedido atualizado!', 'success');
            loadOrders(); // Reload orders
        } else {
            const data = await response.json();
            showMessage(data.error || 'Erro ao atualizar status', 'error');
            loadOrders(); // Reload to reset the select
        }
    } catch (error) {
        console.error('Error updating order status:', error);
        showMessage('Erro de conexão', 'error');
        loadOrders(); // Reload to reset the select
    }
}

async function viewOrderDetail(orderId) {
    const order = orders.find(o => o.id === orderId);
    if (!order) return;
    
    const orderDetail = document.getElementById('orderDetail');
    
    orderDetail.innerHTML = `
        <div style="margin-bottom: 2rem;">
            <h4>Pedido #${order.id}</h4>
            <p><strong>Status:</strong> ${getStatusText(order.status)}</p>
            <p><strong>Data:</strong> ${new Date(order.created_at).toLocaleString('pt-BR')}</p>
            <p><strong>Total:</strong> R$ ${order.total_amount.toFixed(2).replace('.', ',')}</p>
        </div>
        
        <div style="margin-bottom: 2rem;">
            <h4>Endereço de Entrega</h4>
            <p>${order.shipping_address}</p>
            <p>${order.shipping_city}, ${order.shipping_state}</p>
            <p>CEP: ${order.shipping_zip}</p>
        </div>
        
        <div>
            <h4>Itens do Pedido</h4>
            <table class="admin-table">
                <thead>
                    <tr>
                        <th>Produto</th>
                        <th>Quantidade</th>
                        <th>Preço Unit.</th>
                        <th>Subtotal</th>
                    </tr>
                </thead>
                <tbody>
                    ${order.items.map(item => `
                        <tr>
                            <td>${item.product_name}</td>
                            <td>${item.quantity}</td>
                            <td>R$ ${item.price.toFixed(2).replace('.', ',')}</td>
                            <td>R$ ${item.subtotal.toFixed(2).replace('.', ',')}</td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        </div>
    `;
    
    showModal('orderModal');
}

function getStatusText(status) {
    const statusMap = {
        'pending': 'Pendente',
        'confirmed': 'Confirmado',
        'shipped': 'Enviado',
        'delivered': 'Entregue',
        'cancelled': 'Cancelado'
    };
    return statusMap[status] || status;
}

// Users functions
async function loadUsers() {
    const loading = document.getElementById('usersLoading');
    const tableBody = document.getElementById('usersTableBody');
    
    loading.style.display = 'block';
    
    try {
        const response = await fetch(`${API_BASE}/users`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            users = await response.json();
            displayUsers();
        } else {
            tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Erro ao carregar usuários</td></tr>';
        }
    } catch (error) {
        console.error('Error loading users:', error);
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Erro ao carregar usuários</td></tr>';
    } finally {
        loading.style.display = 'none';
    }
}

function displayUsers() {
    const tableBody = document.getElementById('usersTableBody');
    
    if (users.length === 0) {
        tableBody.innerHTML = '<tr><td colspan="7" class="text-center">Nenhum usuário encontrado</td></tr>';
        return;
    }
    
    tableBody.innerHTML = users.map(user => `
        <tr>
            <td>${user.id}</td>
            <td>${user.full_name}</td>
            <td>${user.email}</td>
            <td>${user.username}</td>
            <td>
                <span class="status-badge ${user.is_admin ? 'status-active' : 'status-inactive'}">
                    ${user.is_admin ? 'Sim' : 'Não'}
                </span>
            </td>
            <td>${new Date(user.created_at).toLocaleDateString('pt-BR')}</td>
            <td>
                <button class="action-btn" onclick="viewUserDetail(${user.id})" title="Ver Detalhes">
                    <i class="fas fa-eye"></i>
                </button>
            </td>
        </tr>
    `).join('');
}

function viewUserDetail(userId) {
    const user = users.find(u => u.id === userId);
    if (!user) return;
    
    alert(`Detalhes do usuário:\n\nNome: ${user.full_name}\nEmail: ${user.email}\nUsuário: ${user.username}\nTelefone: ${user.phone || 'N/A'}\nEndereço: ${user.address || 'N/A'}\nCidade: ${user.city || 'N/A'}\nEstado: ${user.state || 'N/A'}\nCEP: ${user.zip_code || 'N/A'}`);
}

// Modal functions
function showModal(modalId) {
    const modal = document.getElementById(modalId);
    const overlay = document.getElementById('overlay');
    
    modal.classList.add('active');
    overlay.classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    const overlay = document.getElementById('overlay');
    
    modal.classList.remove('active');
    overlay.classList.remove('active');
}

function closeOverlay() {
    const overlay = document.getElementById('overlay');
    const modals = document.querySelectorAll('.modal.active');
    
    overlay.classList.remove('active');
    modals.forEach(modal => {
        modal.classList.remove('active');
    });
}

// Utility functions
function showMessage(message, type = 'info') {
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = `message message-${type}`;
    messageEl.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#059669' : '#2563eb'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        max-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    messageEl.textContent = message;
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(messageEl);
    
    // Remove message after 5 seconds
    setTimeout(() => {
        messageEl.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (messageEl.parentNode) {
                messageEl.parentNode.removeChild(messageEl);
            }
        }, 300);
    }, 5000);
}

