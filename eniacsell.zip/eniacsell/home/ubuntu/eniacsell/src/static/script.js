// Global variables
let currentUser = null;
let products = [];
let cart = [];
let categories = [];

// API base URL
const API_BASE = '/api';

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    checkAuthStatus();
    loadProducts();
    loadCategories();
    loadCart();
    setupEventListeners();
});

// Setup event listeners
function setupEventListeners() {
    // Smooth scrolling for navigation
    document.querySelectorAll('.nav-link').forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const target = this.getAttribute('href');
            if (target.startsWith('#')) {
                document.querySelector(target).scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Close modals when clicking outside
    document.addEventListener('click', function(e) {
        if (e.target.classList.contains('modal')) {
            closeModal(e.target.id);
        }
    });

    // Close user menu when clicking outside
    document.addEventListener('click', function(e) {
        const userMenu = document.getElementById('userMenu');
        const userBtn = document.querySelector('.user-btn');
        
        if (!userMenu.contains(e.target) && !userBtn.contains(e.target)) {
            userMenu.classList.remove('active');
        }
    });
}

// Authentication functions
async function checkAuthStatus() {
    try {
        const response = await fetch(`${API_BASE}/current-user`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            currentUser = await response.json();
            updateUserInterface();
        } else {
            currentUser = null;
            updateUserInterface();
        }
    } catch (error) {
        console.error('Error checking auth status:', error);
        currentUser = null;
        updateUserInterface();
    }
}

function updateUserInterface() {
    const loggedOutMenu = document.getElementById('loggedOutMenu');
    const loggedInMenu = document.getElementById('loggedInMenu');
    const userName = document.getElementById('userName');
    const adminLink = document.getElementById('adminLink');

    if (currentUser) {
        loggedOutMenu.style.display = 'none';
        loggedInMenu.style.display = 'block';
        userName.textContent = currentUser.full_name || currentUser.username;
        
        if (currentUser.is_admin) {
            adminLink.style.display = 'block';
        } else {
            adminLink.style.display = 'none';
        }
    } else {
        loggedOutMenu.style.display = 'block';
        loggedInMenu.style.display = 'none';
    }
}

async function handleLogin(event) {
    event.preventDefault();
    
    const username = document.getElementById('loginUsername').value;
    const password = document.getElementById('loginPassword').value;
    
    try {
        const response = await fetch(`${API_BASE}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            currentUser = data.user;
            updateUserInterface();
            closeModal('loginModal');
            showMessage('Login realizado com sucesso!', 'success');
            loadCart(); // Reload cart after login
        } else {
            showMessage(data.error || 'Erro no login', 'error');
        }
    } catch (error) {
        console.error('Login error:', error);
        showMessage('Erro de conexão', 'error');
    }
}

async function handleRegister(event) {
    event.preventDefault();
    
    const formData = {
        full_name: document.getElementById('registerFullName').value,
        username: document.getElementById('registerUsername').value,
        email: document.getElementById('registerEmail').value,
        password: document.getElementById('registerPassword').value,
        phone: document.getElementById('registerPhone').value
    };
    
    try {
        const response = await fetch(`${API_BASE}/users`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify(formData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Cadastro realizado com sucesso! Faça login para continuar.', 'success');
            closeModal('registerModal');
            showLogin();
        } else {
            showMessage(data.error || 'Erro no cadastro', 'error');
        }
    } catch (error) {
        console.error('Register error:', error);
        showMessage('Erro de conexão', 'error');
    }
}

async function logout() {
    try {
        await fetch(`${API_BASE}/logout`, {
            method: 'POST',
            credentials: 'include'
        });
        
        currentUser = null;
        cart = [];
        updateUserInterface();
        updateCartDisplay();
        showMessage('Logout realizado com sucesso!', 'success');
    } catch (error) {
        console.error('Logout error:', error);
    }
}

// Product functions
async function loadProducts() {
    const loading = document.getElementById('productsLoading');
    const grid = document.getElementById('productsGrid');
    
    loading.style.display = 'block';
    
    try {
        const response = await fetch(`${API_BASE}/products`);
        products = await response.json();
        displayProducts(products);
    } catch (error) {
        console.error('Error loading products:', error);
        grid.innerHTML = '<p class="text-center">Erro ao carregar produtos</p>';
    } finally {
        loading.style.display = 'none';
    }
}

async function loadCategories() {
    try {
        const response = await fetch(`${API_BASE}/categories`);
        categories = await response.json();
        
        const categoryFilter = document.getElementById('categoryFilter');
        categoryFilter.innerHTML = '<option value="">Todas as categorias</option>';
        
        categories.forEach(category => {
            const option = document.createElement('option');
            option.value = category;
            option.textContent = category;
            categoryFilter.appendChild(option);
        });
    } catch (error) {
        console.error('Error loading categories:', error);
    }
}

function displayProducts(productsToShow) {
    const grid = document.getElementById('productsGrid');
    
    if (productsToShow.length === 0) {
        grid.innerHTML = '<p class="text-center">Nenhum produto encontrado</p>';
        return;
    }
    
    grid.innerHTML = productsToShow.map(product => `
        <div class="product-card" onclick="showProductDetail(${product.id})">
            <div class="product-image">
                ${product.image_url ? 
                    `<img src="${product.image_url}" alt="${product.name}">` : 
                    '<i class="fas fa-image"></i>'
                }
            </div>
            <div class="product-info">
                <div class="product-name">${product.name}</div>
                <div class="product-description">${product.description || 'Sem descrição'}</div>
                <div class="product-price">R$ ${product.price.toFixed(2).replace('.', ',')}</div>
                <div class="product-actions">
                    <button class="add-to-cart-btn" onclick="event.stopPropagation(); addToCart(${product.id})">
                        <i class="fas fa-cart-plus"></i> Adicionar
                    </button>
                    <button class="view-product-btn" onclick="event.stopPropagation(); showProductDetail(${product.id})">
                        <i class="fas fa-eye"></i>
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

function filterProducts() {
    const categoryFilter = document.getElementById('categoryFilter').value;
    const searchTerm = document.getElementById('searchInput').value.toLowerCase();
    
    let filteredProducts = products;
    
    if (categoryFilter) {
        filteredProducts = filteredProducts.filter(product => 
            product.category === categoryFilter
        );
    }
    
    if (searchTerm) {
        filteredProducts = filteredProducts.filter(product =>
            product.name.toLowerCase().includes(searchTerm) ||
            (product.description && product.description.toLowerCase().includes(searchTerm))
        );
    }
    
    displayProducts(filteredProducts);
}

function searchProducts() {
    filterProducts();
}

async function showProductDetail(productId) {
    const product = products.find(p => p.id === productId);
    if (!product) return;
    
    const modal = document.getElementById('productModal');
    const title = document.getElementById('productModalTitle');
    const detail = document.getElementById('productDetail');
    
    title.textContent = product.name;
    
    detail.innerHTML = `
        <div class="product-detail-content">
            <div class="product-detail-image">
                ${product.image_url ? 
                    `<img src="${product.image_url}" alt="${product.name}">` : 
                    '<i class="fas fa-image"></i>'
                }
            </div>
            <div class="product-detail-info">
                <h3>${product.name}</h3>
                <div class="product-detail-price">R$ ${product.price.toFixed(2).replace('.', ',')}</div>
                <div class="product-detail-description">${product.description || 'Sem descrição disponível'}</div>
                <div class="product-detail-stock">
                    <strong>Estoque:</strong> ${product.stock_quantity} unidades
                </div>
                <div class="product-detail-actions">
                    <button class="add-to-cart-btn" onclick="addToCart(${product.id}); closeModal('productModal')">
                        <i class="fas fa-cart-plus"></i> Adicionar ao Carrinho
                    </button>
                </div>
            </div>
        </div>
    `;
    
    showModal('productModal');
}

// Cart functions
async function loadCart() {
    if (!currentUser) {
        cart = [];
        updateCartDisplay();
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/cart`, {
            credentials: 'include'
        });
        
        if (response.ok) {
            const data = await response.json();
            cart = data.items || [];
            updateCartDisplay();
        }
    } catch (error) {
        console.error('Error loading cart:', error);
    }
}

async function addToCart(productId, quantity = 1) {
    if (!currentUser) {
        showMessage('Faça login para adicionar produtos ao carrinho', 'error');
        showLogin();
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE}/cart/add`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify({ product_id: productId, quantity })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            loadCart(); // Reload cart
            showMessage('Produto adicionado ao carrinho!', 'success');
        } else {
            showMessage(data.error || 'Erro ao adicionar produto', 'error');
        }
    } catch (error) {
        console.error('Error adding to cart:', error);
        showMessage('Erro de conexão', 'error');
    }
}

async function removeFromCart(productId) {
    try {
        const response = await fetch(`${API_BASE}/cart/remove/${productId}`, {
            method: 'DELETE',
            credentials: 'include'
        });
        
        if (response.ok) {
            loadCart(); // Reload cart
            showMessage('Produto removido do carrinho', 'success');
        }
    } catch (error) {
        console.error('Error removing from cart:', error);
    }
}

function updateCartDisplay() {
    const cartContent = document.getElementById('cartContent');
    const cartCount = document.querySelector('.cart-count');
    const cartTotal = document.getElementById('cartTotal');
    
    // Update cart count
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    cartCount.textContent = totalItems;
    
    // Update cart content
    if (cart.length === 0) {
        cartContent.innerHTML = '<p class="text-center">Carrinho vazio</p>';
        cartTotal.textContent = '0,00';
        return;
    }
    
    let total = 0;
    cartContent.innerHTML = cart.map(item => {
        const subtotal = item.product.price * item.quantity;
        total += subtotal;
        
        return `
            <div class="cart-item">
                <div class="cart-item-image">
                    ${item.product.image_url ? 
                        `<img src="${item.product.image_url}" alt="${item.product.name}">` : 
                        '<i class="fas fa-image"></i>'
                    }
                </div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.product.name}</div>
                    <div class="cart-item-price">R$ ${item.product.price.toFixed(2).replace('.', ',')}</div>
                    <div class="cart-item-quantity">
                        <button class="quantity-btn" onclick="updateCartQuantity(${item.product.id}, ${item.quantity - 1})">-</button>
                        <span>${item.quantity}</span>
                        <button class="quantity-btn" onclick="updateCartQuantity(${item.product.id}, ${item.quantity + 1})">+</button>
                        <button class="quantity-btn" onclick="removeFromCart(${item.product.id})" style="margin-left: 1rem; color: #ef4444;">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
    }).join('');
    
    cartTotal.textContent = total.toFixed(2).replace('.', ',');
}

async function updateCartQuantity(productId, newQuantity) {
    if (newQuantity <= 0) {
        removeFromCart(productId);
        return;
    }
    
    // For simplicity, we'll remove and re-add with new quantity
    await removeFromCart(productId);
    await addToCart(productId, newQuantity);
}

function toggleCart() {
    const cartSidebar = document.getElementById('cartSidebar');
    const overlay = document.getElementById('overlay');
    
    cartSidebar.classList.toggle('active');
    overlay.classList.toggle('active');
}

// Checkout function
function goToCheckout() {
    if (!currentUser) {
        showMessage('Faça login para finalizar a compra', 'error');
        showLogin();
        return;
    }
    
    if (cart.length === 0) {
        showMessage('Carrinho vazio', 'error');
        return;
    }
    
    // For now, we'll show a simple checkout form
    showCheckoutModal();
}

function showCheckoutModal() {
    const modal = document.createElement('div');
    modal.className = 'modal active';
    modal.id = 'checkoutModal';
    
    const total = cart.reduce((sum, item) => sum + (item.product.price * item.quantity), 0);
    
    modal.innerHTML = `
        <div class="modal-content">
            <div class="modal-header">
                <h3>Finalizar Compra</h3>
                <button class="close-modal" onclick="closeModal('checkoutModal')">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form onsubmit="handleCheckout(event)">
                <div style="padding: 2rem;">
                    <h4>Endereço de Entrega</h4>
                    <div class="form-group">
                        <label for="checkoutAddress">Endereço:</label>
                        <input type="text" id="checkoutAddress" value="${currentUser.address || ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="checkoutCity">Cidade:</label>
                        <input type="text" id="checkoutCity" value="${currentUser.city || ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="checkoutState">Estado:</label>
                        <input type="text" id="checkoutState" value="${currentUser.state || ''}" required>
                    </div>
                    <div class="form-group">
                        <label for="checkoutZip">CEP:</label>
                        <input type="text" id="checkoutZip" value="${currentUser.zip_code || ''}" required>
                    </div>
                    
                    <h4>Resumo do Pedido</h4>
                    <div style="background: #f9fafb; padding: 1rem; border-radius: 8px; margin-bottom: 1rem;">
                        ${cart.map(item => `
                            <div style="display: flex; justify-content: space-between; margin-bottom: 0.5rem;">
                                <span>${item.product.name} (${item.quantity}x)</span>
                                <span>R$ ${(item.product.price * item.quantity).toFixed(2).replace('.', ',')}</span>
                            </div>
                        `).join('')}
                        <hr>
                        <div style="display: flex; justify-content: space-between; font-weight: bold;">
                            <span>Total:</span>
                            <span>R$ ${total.toFixed(2).replace('.', ',')}</span>
                        </div>
                    </div>
                    
                    <button type="submit" class="submit-btn">Confirmar Pedido</button>
                </div>
            </form>
        </div>
    `;
    
    document.body.appendChild(modal);
}

async function handleCheckout(event) {
    event.preventDefault();
    
    const orderData = {
        shipping_address: document.getElementById('checkoutAddress').value,
        shipping_city: document.getElementById('checkoutCity').value,
        shipping_state: document.getElementById('checkoutState').value,
        shipping_zip: document.getElementById('checkoutZip').value,
        items: cart.map(item => ({
            product_id: item.product.id,
            quantity: item.quantity
        }))
    };
    
    try {
        const response = await fetch(`${API_BASE}/orders`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            credentials: 'include',
            body: JSON.stringify(orderData)
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showMessage('Pedido realizado com sucesso!', 'success');
            closeModal('checkoutModal');
            toggleCart(); // Close cart
            loadCart(); // Reload cart (should be empty now)
            
            // Clear cart on server
            await fetch(`${API_BASE}/cart/clear`, {
                method: 'DELETE',
                credentials: 'include'
            });
        } else {
            showMessage(data.error || 'Erro ao processar pedido', 'error');
        }
    } catch (error) {
        console.error('Checkout error:', error);
        showMessage('Erro de conexão', 'error');
    }
}

// UI helper functions
function toggleUserMenu() {
    const userMenu = document.getElementById('userMenu');
    userMenu.classList.toggle('active');
}

function toggleMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.toggle('active');
}

function closeMobileMenu() {
    const mobileMenu = document.getElementById('mobileMenu');
    mobileMenu.classList.remove('active');
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    const overlay = document.getElementById('overlay');
    
    modal.classList.add('active');
    overlay.classList.add('active');
}

function closeModal(modalId) {
    const modal = document.getElementById(modalId);
    const overlay = document.getElementById('overlay');
    
    modal.classList.remove('active');
    overlay.classList.remove('active');
    
    // Remove dynamically created modals
    if (modalId === 'checkoutModal') {
        modal.remove();
    }
}

function closeOverlay() {
    const overlay = document.getElementById('overlay');
    const cartSidebar = document.getElementById('cartSidebar');
    const userMenu = document.getElementById('userMenu');
    const modals = document.querySelectorAll('.modal.active');
    
    overlay.classList.remove('active');
    cartSidebar.classList.remove('active');
    userMenu.classList.remove('active');
    
    modals.forEach(modal => {
        modal.classList.remove('active');
        if (modal.id === 'checkoutModal') {
            modal.remove();
        }
    });
}

function showLogin() {
    showModal('loginModal');
}

function showRegister() {
    showModal('registerModal');
}

function switchToRegister() {
    closeModal('loginModal');
    showModal('registerModal');
}

function switchToLogin() {
    closeModal('registerModal');
    showModal('loginModal');
}

function scrollToProducts() {
    document.getElementById('products').scrollIntoView({
        behavior: 'smooth'
    });
}

function showProfile() {
    showMessage('Funcionalidade em desenvolvimento', 'info');
}

function showOrders() {
    showMessage('Funcionalidade em desenvolvimento', 'info');
}

function showAdmin() {
    if (currentUser && currentUser.is_admin) {
        window.open('/admin.html', '_blank');
    }
}

function showMessage(message, type = 'info') {
    // Create message element
    const messageEl = document.createElement('div');
    messageEl.className = `message message-${type}`;
    messageEl.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        background: ${type === 'error' ? '#ef4444' : type === 'success' ? '#059669' : '#2563eb'};
        color: white;
        padding: 1rem 1.5rem;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
        z-index: 10000;
        max-width: 300px;
        animation: slideIn 0.3s ease;
    `;
    messageEl.textContent = message;
    
    // Add animation styles
    const style = document.createElement('style');
    style.textContent = `
        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }
        @keyframes slideOut {
            from { transform: translateX(0); opacity: 1; }
            to { transform: translateX(100%); opacity: 0; }
        }
    `;
    document.head.appendChild(style);
    
    document.body.appendChild(messageEl);
    
    // Remove message after 5 seconds
    setTimeout(() => {
        messageEl.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => {
            if (messageEl.parentNode) {
                messageEl.parentNode.removeChild(messageEl);
            }
        }, 300);
    }, 5000);
}

